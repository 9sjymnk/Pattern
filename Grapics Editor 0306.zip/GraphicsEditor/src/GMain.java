public class GMain {

    public static void main(String[] args) {
        GMainFrame mainFrame = new GMainFrame();
        mainFrame.setVisible(true);
    }
}